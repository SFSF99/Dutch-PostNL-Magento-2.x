<?php
namespace OOAWebstore\TNTpostf\Helper;

/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	
    public function __construct(
        \Magento\Framework\App\Helper\Context $context
    ) {
        parent::__construct(
            $context
        );
    }
    
}
