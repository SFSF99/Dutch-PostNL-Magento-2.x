<?php
namespace OOAWebstore\TNTpostf\Model\Carrier;

/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016) 
 *
 */

class Tntpostf extends \Magento\Shipping\Model\Carrier\AbstractCarrier
{
    protected $_code = 'tntpostf';
   
    protected $shippingRateResultFactory;

    protected $quoteQuoteAddressRateResultMethodFactory;

    protected $catalogProductFactory;

    protected $checkoutSession;

    protected $taxCalculation;

    protected $taxConfig;
    
    public $dest_country;    

    public function __construct(
    	\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
    	\Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory $rateErrorFactory,
    	\Psr\Log\LoggerInterface $logger,
        \Magento\Shipping\Model\Rate\ResultFactory $shippingRateResultFactory,
        \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory $quoteQuoteAddressRateResultMethodFactory,
        \Magento\Catalog\Model\ProductFactory $catalogProductFactory,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Tax\Model\Calculation $taxCalculation,
        \Magento\Tax\Model\Config $taxConfig,
    	array $data = []    		
    ) {
        $this->shippingRateResultFactory = $shippingRateResultFactory;
        $this->quoteQuoteAddressRateResultMethodFactory = $quoteQuoteAddressRateResultMethodFactory;
        $this->catalogProductFactory = $catalogProductFactory;
        $this->checkoutSession = $checkoutSession;
        $this->taxCalculation = $taxCalculation;
        $this->taxConfig = $taxConfig;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }
    
    public function collectRates(\Magento\Quote\Model\Quote\Address\RateRequest $request)
    {

     if (!$this->getConfigFlag('active')) {
       return (FALSE);
     }

     // new start added
     $freeBoxes = 0;
     if ($request->getAllItems()) {
       foreach ($request->getAllItems() as $item) {

         if ($item->getProduct()->isVirtual() || $item->getParentItem()) {
     	   continue;
     	 }

     	 if ($item->getHasChildren() && $item->isShipSeparately()) {
     	   foreach ($item->getChildren() as $child) {
     		 if ($child->getFreeShipping() && !$child->getProduct()->isVirtual()) {
     		   $freeBoxes += $item->getQty() * $child->getQty();
     		 }
     	   }
     	 } elseif ($item->getFreeShipping()) {
     	   $freeBoxes += $item->getQty();
     	 }
       }
     }
     $this->setFreeBoxes($freeBoxes);

     if ($request->getFreeShipping() === true || $request->getPackageQty() == $this->getFreeBoxes()) {
       $_result	= $this->shippingRateResultFactory->create();
   	   $_method	= $this->quoteQuoteAddressRateResultMethodFactory->create();
   	   $_method->setCarrier($this->_code);
       $_method->setCarrierTitle(__('MODULE_SHIPPING_TNTPOST_F_TEXT_NAME'));
       $_method->setMethod($this->_code);
       $_method->setMethodTitle($this->getConfigData('name'));
       $_method->setCost(0.00);
       $_method->setPrice(0.00);
       $_result->append($_method);
       return $_result;
     }
     // new stop added

     $tnt_f_tnt = 0;
     $tnt_f_lp_1 = 0;
     $tnt_f_lp_1_height = 0;
     $tnt_f_lp_1_volume = 0.0;
     $tnt_f_lp_4 = 0;
     $tnt_f_sb = 0;
     $tnt_f_total_ex_tax = 0.0;
     $tnt_f_weight = 0;
     // get some values products
     foreach ($request->getAllItems() as $item) { // getAttributeText('tntpostf_shipping')
       if ($item->getProduct()->isVirtual() || $item->getParentItem()) {
         continue;
       }

       $productModel = $this->catalogProductFactory->create();
	   $product_tnt_f_tnt = (int)$productModel->load($item->getProduct()->getId())->getTntpostfShipping();
	   $product_tnt_f_lp = (int)$productModel->load($item->getProduct()->getId())->getTntpostfPackage();
	   $product_tnt_f_sb = (int)$productModel->load($item->getProduct()->getId())->getTntpostfSealbag();
	   $product_height = (float)$productModel->load($item->getProduct()->getId())->getTntpostfHeight();
	   $product_maxplet = (int)$productModel->load($item->getProduct()->getId())->getTntpostfMaxplet();
	   if ($product_maxplet == 0) {
	   	 $product_maxplet = 1;
	   }

       if ($product_tnt_f_tnt == 0) {
         $tnt_f_tnt += 1;
       }
       if ($product_tnt_f_lp == 0) {
         $tnt_f_lp_1 += 1;
         $tnt_f_lp_1_height += $item->getQty() * $product_height;
         $tnt_f_lp_1_volume += $item->getQty() / $product_maxplet;
       }
       if ($product_tnt_f_lp == 1) {
         $tnt_f_lp_4 += 1;
       }
       if ($product_tnt_f_sb > $tnt_f_sb) {
         $tnt_f_sb = $product_tnt_f_sb;
       }
	   $price = $item->getPrice();
       $subtotal = $item->getPrice() * $item->getQty();
	   $tnt_f_total_ex_tax += $subtotal;
	   $tnt_f_weight += $item->getWeight() * $item->getQty();
	 }

     $total_weight = ceil($tnt_f_weight); // weight calculated in grams

     // determine if we are domestic or international
     $shippingdata = $this->checkoutSession->getQuote()->getShippingAddress()->getData();
     $sub_total = $shippingdata['subtotal_incl_tax']; // included VAT
     //$this->dest_country = $shippingdata['country_id'];
     $this->dest_country = $request->getDestCountryId();

     // build all arrays with rates, determine max. weight, options and classify delivery country and zone
     if ($this->dest_country == 'NL') {
         $rates_no_le_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_NO_LE_HO_CO')); // rates normal letters home country (=LETTER)
         $max_weight_no_le_ho_co = $this->determine_max_weight($rates_no_le_ho_co);
         $rates_re_le_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_RE_LE_HO_CO')); // rates registered letters home country (=REGISTERED)
         $max_weight_re_le_ho_co = $this->determine_max_weight($rates_re_le_ho_co);
         $rates_no_le_ho_co_lp = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_NO_LE_HO_CO_LP')); // rates normal letterboxpackage home country (=LETTER)
         $max_weight_no_le_ho_co_lp = $this->determine_max_weight($rates_no_le_ho_co_lp);
         $rates_re_le_ho_co_lp = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_RE_LE_HO_CO_LP')); // rates registered letterboxpackage home country (=REGISTERED)
         $max_weight_re_le_ho_co_lp = $this->determine_max_weight($rates_re_le_ho_co_lp);
         $rates_rei_le_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_REI_LE_HO_CO')); // rates insurance registered letters home country (=INSURANCESERVICE)
         $max_weight_rei_le_ho_co = $this->determine_max_weight($rates_rei_le_ho_co);
         $rates_ga_le_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_GA_LE_HO_CO')); // rates guaranteed letters home country (=SPEEDSERVICE)
         $max_weight_ga_le_ho_co = $this->determine_max_weight($rates_ga_le_ho_co);
         $rates_cod_le_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_COD_LE_HO_CO')); // rates COD letters (=PAYSERVICE)
         $max_weight_cod_le_ho_co = $this->determine_max_weight($rates_cod_le_ho_co);
         $rates_ba_pa_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_BA_PA_HO_CO')); // rates basic packages home country (=PACKAGE)
         $max_weight_ba_pa_ho_co = $this->determine_max_weight($rates_ba_pa_ho_co);
         $rates_re_pa_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_RE_PA_HO_CO')); // rates registered packages home country (=REGISTERED)
         $max_weight_re_pa_ho_co = $this->determine_max_weight($rates_re_pa_ho_co);
         $rates_rei_pa_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_REI_PA_HO_CO')); // rates insurance registered packages home country (=INSURANCESERVICE)
         $max_weight_rei_pa_ho_co = $this->determine_max_weight($rates_rei_pa_ho_co);
         $rates_ga_pa_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_GA_PA_HO_CO')); // rates guaranteed packages home country (=SPEEDSERVICE)
         $max_weight_ga_pa_ho_co = $this->determine_max_weight($rates_ga_pa_ho_co);
         $rates_cod_pa_ho_co = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_COD_PA_HO_CO')); // rates COD packages home country (=PAYSERVICE)
         $max_weight_cod_pa_ho_co = $this->determine_max_weight($rates_cod_pa_ho_co);
     } else {
         $rates_no_le_eur_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_NO_LE_EUR_PR')); // rates normal letters Europe priority (= LETTER)
         $max_weight_no_le_wo = $this->determine_max_weight($rates_no_le_eur_pr);
         $rates_no_le_wo_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_NO_LE_WO_PR')); // rates normal letters outside Europe priority
         $rates_re_le_eur_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_RE_LE_EUR_PR')); // rates registered letters Europe priority (=REGISTERED)
         $rates_re_le_wo_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_RE_LE_WO_PR')); // rates registered letters outside Europe priority
         $rates_rei_le_eur = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_REI_LE_EUR')); // rates insurance registered letters Europe priority (=INSURANCESERVICE)
         $rates_rei_le_wo = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_REI_LE_WO')); // rates insurance registered letters outside Europe priority
         $max_weight_rei_le_wo = $this->determine_max_weight($rates_rei_le_wo);
         $rates_ga_le_eur = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_GA_LE_EUR')); // rates guaranteed letters Europe priority (=SPEEDSERVICE)
         $rates_ga_le_wo = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_GA_LE_WO')); // rates guaranteed letters outside Europe priority
         $rates_1_ba_pa_eur_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_1_BA_PA_EUR_PR')); // rates basic packages zone EUR 1 Europe (=PACKAGE)
         $rates_2_ba_pa_eur_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_2_BA_PA_EUR_PR')); // rates basic packages zone EUR 2 Europe
         $rates_4_ba_pa_eur_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_4_BA_PA_EUR_PR')); // rates basic packages zone EUR 3 Europe
         $rates_5_ba_pa_wo_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_5_BA_PA_WO_PR')); // rates basic packages zone outside Europe
         $max_weight_12_ba_pa = $this->determine_max_weight($rates_1_ba_pa_eur_pr);
         $max_weight_45_ba_pa = $this->determine_max_weight($rates_5_ba_pa_wo_pr);
         $rates_1_re_pa_eur_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_1_RE_PA_EUR_PR')); // rates registered packages zone EUR 1 Europe (=REGISTERED)
         $rates_2_re_pa_eur_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_2_RE_PA_EUR_PR')); // rates registered packages zone EUR 2 Europe
         $rates_4_re_pa_eur_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_4_RE_PA_EUR_PR')); // rates registered packages zone EUR 3 Europe
         $rates_5_re_pa_wo_pr = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_5_RE_PA_WO_PR')); // rates registered packages zone outside Europe
         $rates_1_rei_pa_eur = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_1_REI_PA_EUR')); // rates insurance registered packages zone EUR 1 Europe (=INSURANCESERVICE)
         $rates_2_rei_pa_eur = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_2_REI_PA_EUR')); // rates insurance registered packages zone EUR 2 Europe
         $rates_4_rei_pa_eur = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_4_REI_PA_EUR')); // rates insurance registered packages zone EUR 3 Europe
         $rates_5_rei_pa_wo = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_5_REI_PA_WO')); // rates insurance registered packages zone outside Europe
         $rates_1_ga_pa_eur = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_1_GA_PA_EUR')); // rates guaranteed packages zone EUR 1 Europe (=SPEEDSERVICE)
         $rates_2_ga_pa_eur = preg_split("/[:,]/" , $this->getConfigData('MODULE_SH_TNT_RATES_2_GA_PA_EUR')); // rates guaranteed packages zone EUR 2 Europe
         $max_weight_12_ga_pa = $this->determine_max_weight($rates_1_ga_pa_eur);

         // classify delivery country and zone
         $country_europe = $this->classify_country_zone('TNT_EUR'); // Europe
         $country_zone1 = $this->classify_country_zone('TNT_ZONE_EUR1'); // EUR 1
         $country_zone2 = $this->classify_country_zone('TNT_ZONE_EUR2'); // EUR 2
         $country_zone4 = $this->classify_country_zone('TNT_ZONE_EUR3'); // EUR 3
         $country_zone5 = !($country_zone1 or $country_zone2 or $country_zone4); // World
     }

     // determine kind of package
     if (($tnt_f_tnt > 0) or (($tnt_f_lp_1 == 0) and ($tnt_f_lp_4 == 0))
         or ((float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT') < 10000)) {
         return (FALSE); // no TNT, or not specified, or max. weight shipping < 10000 gr (not workable for calculations)
     }
     if ($tnt_f_lp_4 > 0) {
       $tnt_f_lp = 4; // package
     } else {
   	   $tnt_f_lp = 1; // letter(s)
   	 }

   	 if ($this->dest_country == 'NL') {
   	     if (($tnt_f_lp == 1) and ((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_WEIGHT')) > $max_weight_no_le_ho_co) or
   	     		                   (((((int)$this->getConfigData('MODULE_SH_TNT_HEIGHT_VOLUME')) == 0) and ($tnt_f_lp_1_height > ((float)$this->getConfigData('MODULE_SH_TNT_LETTER_HEIGHT')))) or
   	     		                    ((((int)$this->getConfigData('MODULE_SH_TNT_HEIGHT_VOLUME')) == 1) and ($tnt_f_lp_1_volume > 1)))
   	     		                  )) { // max. weight letter or max. height letter
   	         $tnt_f_lp = 4; // package
   	     }
         // if letter not allowed change it to package
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_NO_LE_HO_CO') == 0) and ($this->getConfigData('MODULE_SH_TNT_RE_LE_HO_CO') == 0)
         		              and ($this->getConfigData('MODULE_SH_TNT_NO_LE_HO_CO_LP') == 0) and ($this->getConfigData('MODULE_SH_TNT_RE_LE_HO_CO_LP') == 0)
                              and ($this->getConfigData('MODULE_SH_TNT_GA_LE_HO_CO') == 0) and ($this->getConfigData('MODULE_SH_TNT_COD_LE_HO_CO') == 0)
                              and ($this->getConfigData('MODULE_SH_TNT_REI_LE_HO_CO') == 0)) {
             $tnt_f_lp = 4;
         }
   	 } else {
   	     if (($tnt_f_lp == 1) and ((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_WEIGHT')) > $max_weight_no_le_wo) or
   	     		                   (((((int)$this->getConfigData('MODULE_SH_TNT_HEIGHT_VOLUME')) == 0) and ($tnt_f_lp_1_height > ((float)$this->getConfigData('MODULE_SH_TNT_LETTER_HEIGHT')))) or
   	     		                    ((((int)$this->getConfigData('MODULE_SH_TNT_HEIGHT_VOLUME')) == 1) and ($tnt_f_lp_1_volume > 1)))
   	     		                  )) { // max. weight letter or max. height/volume letter
   	     	 $tnt_f_lp = 4; // package
   	     }

         // if letter not allowed change it to package
   	     if (($tnt_f_lp == 1) and ((($country_europe == TRUE) and ($this->getConfigData('MODULE_SH_TNT_NO_LE_EUR_PR') == 0)) or
                                   (($country_europe == FALSE) and ($this->getConfigData('MODULE_SH_TNT_NO_LE_WO_PR') == 0)))
                              and ((($country_europe == TRUE) and ($this->getConfigData('MODULE_SH_TNT_RE_LE_EUR_PR') == 0)) or
                                   (($country_europe == FALSE) and ($this->getConfigData('MODULE_SH_TNT_RE_LE_WO_PR') == 0)))
                              and ((($country_europe == TRUE) and ($this->getConfigData('MODULE_SH_TNT_REI_LE_EUR') == 0)) or
                                   (($country_europe == FALSE) and ($this->getConfigData('MODULE_SH_TNT_REI_LE_WO') == 0)))
                              and ((($country_europe == TRUE) and ($this->getConfigData('MODULE_SH_TNT_GA_LE_EUR') == 0)) or
                                   (($country_europe == FALSE) and ($this->getConfigData('MODULE_SH_TNT_GA_LE_WO') == 0)))) {
             $tnt_f_lp = 4;
         }
   	 }

     // if no multiple packages are not alowed, no TNT will be used when multiple packages are necessary because
     // of the max. shipping weight

     // other variables
     $tnt_f_rate = 0.0;
     $tnt_f_rate_ins = 0.0;
     $tnt_f_units = 0;
     $tnt_f_weight = 0.0;
     $tnt_f_weight_lb = 0.0;
     $methods = array();
     $total_costs = 0.0;
     $title = '';

     if ($tnt_f_lp == 1) {
       $total_weight += (float)$this->getConfigData('MODULE_SH_TNT_LETTER_WEIGHT'); // later added, for packages already programmed
     }

     if ($this->dest_country == 'NL') {
     //**********************  NORMAL DUTCH LETTER (=LETTER) ********************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_NO_LE_HO_CO') == 1) and
             ($total_weight <= $max_weight_no_le_ho_co) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT'))) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_no_le_ho_co, $tnt_f_weight);
             if ($tnt_f_weight <= (float)$this->getConfigData('MODULE_SH_TNT_FREE_WGHT_LE_HO_CO')) {
				 $tnt_f_rate = 0.0;
             }
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_NO_LETTER');
			 $methods[] = array('id' => 'NOLEHOCO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  REGISTERED DUTCH LETTER (=REGISTERED) ************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_RE_LE_HO_CO') == 1) and
             ($total_weight <= $max_weight_re_le_ho_co) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT'))) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_re_le_ho_co, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_LETTER');
			 $methods[] = array('id' => 'RELEHOCO',
                                'title' => $title,
                                'cost' => $total_costs);
         }

     //**********************  NORMAL DUTCH LETTERBOXPACKAGE (=LETTER) ********************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_NO_LE_HO_CO_LP') == 1) and
         		($total_weight <= $max_weight_no_le_ho_co_lp) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT'))) {
         	$tnt_f_units = 1;
         	$tnt_f_weight = (float)$total_weight;
         	$tnt_f_rate = $this->determine_rate($rates_no_le_ho_co_lp, $tnt_f_weight);
         	$total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
         	$title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_NO_LETTER_LP');
         	$methods[] = array('id' => 'NOLEHOCOLP',
				         	   'title' => $title,
				         	   'cost' => $total_costs);
         }
      //**********************  REGISTERED DUTCH LETTERBOXPACKAGE (=REGISTERED) ************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_RE_LE_HO_CO_LP') == 1) and
         		($total_weight <= $max_weight_re_le_ho_co_lp) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT'))) {
         	$tnt_f_units = 1;
         	$tnt_f_weight = (float)$total_weight;
         	$tnt_f_rate = $this->determine_rate($rates_re_le_ho_co_lp, $tnt_f_weight);
         	$total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
         	$title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_LETTER_LP');
         	$methods[] = array('id' => 'RELEHOCOLP',
         					   'title' => $title,
         					   'cost' => $total_costs);
         }
     //**********************  (=INSURANCESERVICE)  *****************************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_REI_LE_HO_CO') == 1) and
             ($total_weight <= $max_weight_rei_le_ho_co) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT'))) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_rei_le_ho_co, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             if (($this->getConfigData('MODULE_SH_TNT_SB') == 1) and ($tnt_f_sb == TRUE)) {
               $total_costs += (float)$this->getConfigData('MODULE_SH_TNT_PRICE_SB');
             }
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_LETTER');
			 $methods[] = array('id' => 'REILEHOCO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  GUARANTEED DUTCH LETTER (=SPEEDSERVICE) **********************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_GA_LE_HO_CO') == 1) and
             ($total_weight <= $max_weight_ga_le_ho_co) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT'))) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_ga_le_ho_co, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_GA_LETTER');
			 $methods[] = array('id' => 'GALEHOCO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  COD DUTCH LETTER (=PAYSERVICE) *******************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_COD_LE_HO_CO') == 1) and
             ($total_weight <= $max_weight_cod_le_ho_co) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT'))) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_cod_le_ho_co, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING')
                                        + (float)$this->getConfigData('MODULE_SH_TNT_COD_HANDLING');
             // the customer has to pay the commission, so the customer has to pay E(xtra) more, so T(otal) + E
             // the calculation for E = (C(omission percentage)x T) / (1 - C), T and E are incl. VAT
             // so E without VAT must be calculated finally, and to add to $total_costs of course
             $V = $this->get_shipping_tax_rate();
             if (((float)$this->getConfigData('MODULE_SH_TNT_COD_COMMISSION') > 0) and ((float)$this->getConfigData('MODULE_SH_TNT_COD_COMMISSION') < 100)) {
             	 $T = (float)($sub_total + ($total_costs * (1 + $V)));
             	 $E = (float)((((float)$this->getConfigData('MODULE_SH_TNT_COD_COMMISSION') / 100) * $T) /
                              (1 - ((float)$this->getConfigData('MODULE_SH_TNT_COD_COMMISSION') / 100)));
                 $E_ex_VAT = (float)($E / (1 + $V));
                 $total_costs += $E_ex_VAT;
             }
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_COD_LETTER');
             if (($sub_total + ($total_costs * (1 + $V))) <= (float)$this->getConfigData('MODULE_SH_TNT_COD_MAX_AMOUNT')) {
			     $methods[] = array('id' => 'CODLEHOCO',
                                    'title' => $title,
                                    'cost' => $total_costs);
             }
         }
     //**********************  BASIC DUTCH PACKAGE (=PACKAGE) *******************************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_BA_PA_HO_CO') == 1) and
             (((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_ba_pa_ho_co) and
               (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_NO_HO_CO') == 1))) {
             $parameters = $this->determine_units_weight_lb($max_weight_ba_pa_ho_co, $total_weight);
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             $tnt_f_rate = $this->determine_rate($rates_ba_pa_ho_co, $tnt_f_weight);
             $total_costs = ($tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING')));
             if ($tnt_f_weight_lb > 0) {
                 $tnt_f_rate = $this->determine_rate($rates_ba_pa_ho_co, $tnt_f_weight_lb);
                 $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
             }
             if ($tnt_f_weight_lb == 0) {
                 $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_BA_PACKAGE');
             } else {
              	 $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ' .
              	          __('MODULE_SHIPPING_TNTPOST_F_TEXT_BA_PACKAGE');
             }
			 $methods[] = array('id' => 'BAPAHOCO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  REGISTERED DUTCH PACKAGE (=REGISTERD) ************************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_RE_PA_HO_CO') == 1) and
             (((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_re_pa_ho_co) and
               (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_RE_HO_CO') == 1))) {
             $parameters = $this->determine_units_weight_lb($max_weight_re_pa_ho_co, $total_weight);
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             $tnt_f_rate = $this->determine_rate($rates_re_pa_ho_co, $tnt_f_weight);
             $total_costs = ($tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING')));
             if ($tnt_f_weight_lb > 0) {
                 $tnt_f_rate = $this->determine_rate($rates_re_pa_ho_co, $tnt_f_weight_lb);
                 $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
             }
             if ($tnt_f_weight_lb == 0) {
                 $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_PACKAGE');
             } else {
              	 $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ' .
              	          __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_PACKAGE');
             }
			 $methods[] = array('id' => 'REPAHOCO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  (=INSURANCESERVICE)  *****************************************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_REI_PA_HO_CO') == 1) and
             (((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_rei_pa_ho_co) and
               (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_INS_HO_CO') == 1))) {
             $parameters = $this->determine_units_weight_lb($max_weight_rei_pa_ho_co, $total_weight);
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             $tnt_f_rate = $this->determine_rate($rates_rei_pa_ho_co, $tnt_f_weight);
             $total_costs = ($tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING')));
             if ($tnt_f_weight_lb > 0) {
                 $tnt_f_rate = $this->determine_rate($rates_rei_pa_ho_co, $tnt_f_weight_lb);
                 $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
             }
             if (($this->getConfigData('MODULE_SH_TNT_SB') == 1) and ($tnt_f_sb == TRUE)) {
               if ($tnt_f_weight_lb == 0) {
                 $total_costs += (float)($tnt_f_units * $this->getConfigData('MODULE_SH_TNT_PRICE_SB'));
               } else {
                 $total_costs += (float)(($tnt_f_units + 1) * $this->getConfigData('MODULE_SH_TNT_PRICE_SB'));
               }
             }
             if ($tnt_f_weight_lb == 0) {
                 $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_PACKAGE');
             } else {
              	 $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ' .
              	          __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_PACKAGE');
             }
			 $methods[] = array('id' => 'REIPAHOCO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  GUARANTEED DUTCH PACKAGE (=SPEEDSERVICE) *********************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_GA_PA_HO_CO') == 1) and
             ((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_ga_pa_ho_co) and
               (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT');
             $tnt_f_rate = $this->determine_rate($rates_ga_pa_ho_co, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_GA_PACKAGE');
			 $methods[] = array('id' => 'GAPAHOCO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  COD DUTCH PACKAGE  (=PAYSERVICE)  ****************************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_COD_PA_HO_CO') == 1) and
             (((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_cod_pa_ho_co) and
               (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_COD_HO_CO') == 1))) {
             $parameters = $this->determine_units_weight_lb($max_weight_cod_pa_ho_co, $total_weight);
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             $tnt_f_rate = $this->determine_rate($rates_cod_pa_ho_co, $tnt_f_weight);
             $total_costs = ($tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING')))
                            + (float)$this->getConfigData('MODULE_SH_TNT_COD_HANDLING');
             if ($tnt_f_weight_lb > 0) {
                 $tnt_f_rate = $this->determine_rate($rates_cod_pa_ho_co, $tnt_f_weight_lb);
                 $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
             }
             // the customer has to pay the commission, so the customer has to pay E(xtra) more, so T(otal) + E
             // the calculation for E = (C(omission percentage)x T) / (1 - C), T and E are incl. VAT
             // so E without VAT must be calculated finally, and to add to $total_costs of course
             $V = $this->get_shipping_tax_rate();
             if (((float)$this->getConfigData('MODULE_SH_TNT_COD_COMMISSION') > 0) and ((float)$this->getConfigData('MODULE_SH_TNT_COD_COMMISSION') < 100)) {
             	 $T = (float)($sub_total + ($total_costs * (1 + $V)));
             	 $E = (float)((((float)$this->getConfigData('MODULE_SH_TNT_COD_COMMISSION') / 100) * $T) /
                              (1 - ((float)$this->getConfigData('MODULE_SH_TNT_COD_COMMISSION') / 100)));
                 $E_ex_VAT = (float)($E / (1 + $V));
                 $total_costs += $E_ex_VAT;
             }
             if ($tnt_f_weight_lb == 0) {
                 $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_COD_PACKAGE');
             } else {
             	 $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ' .
             	          __('MODULE_SHIPPING_TNTPOST_F_TEXT_COD_PACKAGE');
             	 $tnt_f_units += 1;
               }
             if ((($sub_total + ($total_costs * (1 + $V))) / $tnt_f_units) <=
                 (float)$this->getConfigData('MODULE_SH_TNT_COD_MAX_AMOUNT')) {
       		     $methods[] = array('id' => 'CODPAHOCO',
                                    'title' => $title,
                                    'cost' => $total_costs);
             }
         }
     //**********************  NO TNT  ******************************************************************
         if (sizeof($methods) == 0) {
             return (FALSE); // no methods specified
         }
     } else {
     //**********************  NORMAL LETTER EUROPE PRIORITY  (=LETTER) *********************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_NO_LE_EUR_PR') == 1) and
             ($total_weight <= $max_weight_no_le_wo) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) and
             ($country_europe == TRUE)) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_no_le_eur_pr, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_NO_EUR_PR_LETTER');
			 $methods[] = array('id' => 'NOLEEURPR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  NORMAL LETTER WORLD PRIORITY (=LETTER) ***********************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_NO_LE_WO_PR') == 1) and
             ($total_weight <= $max_weight_no_le_wo) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) and
             ($country_europe == FALSE)) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_no_le_wo_pr, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_NO_WO_PR_LETTER');
			 $methods[] = array('id' => 'NOLEWOPR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  REGISTERED LETTER EUROPE PRIORITY (=REGISTERED) **************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_RE_LE_EUR_PR') == 1) and
             ($total_weight <= $max_weight_no_le_wo) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) and
             ($country_europe == TRUE)) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_re_le_eur_pr, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_EUR_PR_LETTER');
			 $methods[] = array('id' => 'RELEEURPR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  REGISTERED LETTER WORLD PRIORITY (=REGISTERED) ***************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_RE_LE_WO_PR') == 1) and
             ($total_weight <= $max_weight_no_le_wo) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) and
             ($country_europe == FALSE)) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_re_le_wo_pr, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_WO_PR_LETTER');
			 $methods[] = array('id' => 'RELEWOPR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  (=INSURANCESERVICE)  *****************************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_REI_LE_EUR') == 1) and
             ($total_weight <= $max_weight_no_le_wo) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) and
             ($country_europe == TRUE)) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_rei_le_eur, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $total_costs += (float)$this->getConfigData('MODULE_SH_TNT_PRICE_SB');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_EUR_PR_LETTER');
			 $methods[] = array('id' => 'REILEEUR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  (=INSURANCESERVICE)  *****************************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_REI_LE_WO') == 1) and
             ($total_weight <= $max_weight_no_le_wo) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) and
             ($country_europe == FALSE)) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_rei_le_wo, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $total_costs += (float)$this->getConfigData('MODULE_SH_TNT_PRICE_SB');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_WO_PR_LETTER');
			 $methods[] = array('id' => 'REILEWO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  (=SPEEDSERVICE)  *********************************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_GA_LE_EUR') == 1) and
             ($total_weight <= $max_weight_no_le_wo) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) and
             ($country_europe == TRUE)) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_ga_le_eur, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_GA_EUR_PR_LETTER');
			 $methods[] = array('id' => 'GALEEUR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  (=SPEEDSERVICE)  *********************************************************
         if (($tnt_f_lp == 1) and ($this->getConfigData('MODULE_SH_TNT_GA_LE_WO') == 1) and
             ($total_weight <= $max_weight_no_le_wo) and ($total_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) and
             ($country_europe == FALSE)) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight;
             $tnt_f_rate = $this->determine_rate($rates_ga_le_wo, $tnt_f_weight);
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_LETTER_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ' . __('MODULE_SHIPPING_TNTPOST_F_TEXT_GA_WO_PR_LETTER');
			 $methods[] = array('id' => 'GALEWO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  BASIC PACKAGE EUROPE PRIORITY (=PACKAGE) *********************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_BA_PA_EUR_PR') == 1) and
             (($country_zone1 == TRUE) or ($country_zone2 == TRUE) or ($country_zone4 == TRUE)) and
             ((((($country_zone4 != TRUE) and (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_12_ba_pa)) or
                (($country_zone4 == TRUE) and (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_45_ba_pa))) and
               (($total_weight  + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_BA_WO') == 1))) {
             if ($country_zone4 == TRUE) {
               $parameters = $this->determine_units_weight_lb($max_weight_45_ba_pa, $total_weight);
             } else {
               $parameters = $this->determine_units_weight_lb($max_weight_12_ba_pa, $total_weight);
             }
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             if ($country_zone1 == TRUE) {
               $tnt_f_rate = $this->determine_rate($rates_1_ba_pa_eur_pr, $tnt_f_weight);
             } elseif ($country_zone2 == TRUE) {
               $tnt_f_rate = $this->determine_rate($rates_2_ba_pa_eur_pr, $tnt_f_weight);
             } else {
               $tnt_f_rate = $this->determine_rate($rates_4_ba_pa_eur_pr, $tnt_f_weight);
             }
             $total_costs = $tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING'));
             if ($tnt_f_weight_lb == 0) {
               $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ';
             } else {
               if ($country_zone1 == TRUE) {
                 $tnt_f_rate = $this->determine_rate($rates_1_ba_pa_eur_pr, $tnt_f_weight_lb);
               } elseif ($country_zone2 == TRUE) {
                 $tnt_f_rate = $this->determine_rate($rates_2_ba_pa_eur_pr, $tnt_f_weight_lb);
               } else {
                 $tnt_f_rate = $this->determine_rate($rates_4_ba_pa_eur_pr, $tnt_f_weight_lb);
               }
               $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
               $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ';
             }
             if ($country_zone1 == TRUE) {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_BA_EUR_PR_Z1_PACKAGE');
             } elseif ($country_zone2 == TRUE) {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_BA_EUR_PR_Z2_PACKAGE');
             } else {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_BA_EUR_PR_Z4_PACKAGE');
             }
             $methods[] = array('id' => 'BAPAEURPR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  BASIC PACKAGE WORLD PRIORITY (=PACKAGE)  *********************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_BA_PA_WO_PR') == 1) and
             ($country_zone5 == TRUE) and
             (((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_45_ba_pa) and
               (($total_weight  + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_BA_WO') == 1))) {
             $parameters = $this->determine_units_weight_lb($max_weight_45_ba_pa, $total_weight);
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             $tnt_f_rate = $this->determine_rate($rates_5_ba_pa_wo_pr, $tnt_f_weight);
             $total_costs = $tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING'));
             if ($tnt_f_weight_lb == 0) {
               $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ';
             } else {
               $tnt_f_rate = $this->determine_rate($rates_5_ba_pa_wo_pr, $tnt_f_weight_lb);
               $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
               $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ';
             }
             $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_BA_WO_PR_Z5_PACKAGE');
             $methods[] = array('id' => 'BAPAWOPR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  REGISTERED PACKAGE EUROPE PRIORITY (=REGISTERED)  ************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_RE_PA_EUR_PR') == 1) and
             (($country_zone1 == TRUE) or ($country_zone2 == TRUE) or ($country_zone4 == TRUE)) and
             ((((($country_zone4 != TRUE) and (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_12_ba_pa)) or
                (($country_zone4 == TRUE) and (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_45_ba_pa))) and
               (($total_weight  + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_RE_WO') == 1))) {
             if ($country_zone4 == TRUE) {
               $parameters = $this->determine_units_weight_lb($max_weight_45_ba_pa, $total_weight);
             } else {
               $parameters = $this->determine_units_weight_lb($max_weight_12_ba_pa, $total_weight);
             }
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             if ($country_zone1 == TRUE) {
               $tnt_f_rate = $this->determine_rate($rates_1_re_pa_eur_pr, $tnt_f_weight);
             } elseif ($country_zone2 == TRUE) {
               $tnt_f_rate = $this->determine_rate($rates_2_re_pa_eur_pr, $tnt_f_weight);
             } else {
               $tnt_f_rate = $this->determine_rate($rates_4_re_pa_eur_pr, $tnt_f_weight);
             }
             $total_costs = $tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING'));
             if ($tnt_f_weight_lb == 0) {
               $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ';
             } else {
               if ($country_zone1 == TRUE) {
                 $tnt_f_rate = $this->determine_rate($rates_1_re_pa_eur_pr, $tnt_f_weight_lb);
               } elseif ($country_zone2 == TRUE) {
                 $tnt_f_rate = $this->determine_rate($rates_2_re_pa_eur_pr, $tnt_f_weight_lb);
               } else {
                 $tnt_f_rate = $this->determine_rate($rates_4_re_pa_eur_pr, $tnt_f_weight_lb);
               }
               $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
               $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ';
             }
             if ($country_zone1 == TRUE) {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_EUR_PR_Z1_PACKAGE');
             } elseif ($country_zone2 == TRUE) {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_EUR_PR_Z2_PACKAGE');
             } else {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_EUR_PR_Z4_PACKAGE');
             }
             $methods[] = array('id' => 'REPAEURPR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  REGISTERED PACKAGE WORLD PRIORITY (=REGISTERED)  *************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_RE_PA_WO_PR') == 1) and
             ($country_zone5 == TRUE) and
             (((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_45_ba_pa) and
               (($total_weight  + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_RE_WO') == 1))) {
             $parameters = $this->determine_units_weight_lb($max_weight_45_ba_pa, $total_weight);
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             $tnt_f_rate = $this->determine_rate($rates_5_re_pa_wo_pr, $tnt_f_weight);
             $total_costs = $tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING'));
             if ($tnt_f_weight_lb == 0) {
               $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ';
             } else {
               $tnt_f_rate = $this->determine_rate($rates_5_re_pa_wo_pr, $tnt_f_weight_lb);
               $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
               $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ';
             }
             $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_RE_WO_PR_Z5_PACKAGE');
             $methods[] = array('id' => 'REPAWOPR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  (=INSURANCESERVICE)  *****************************************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_REI_PA_EUR') == 1) and
             (($country_zone1 == TRUE) or ($country_zone2 == TRUE) or ($country_zone4 == TRUE)) and
             ((((($country_zone4 != TRUE) and (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_12_ba_pa)) or
                (($country_zone4 == TRUE) and (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_45_ba_pa))) and
               (($total_weight  + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_REI_WO') == 1))) {
             if ($country_zone4 == TRUE) {
               $parameters = $this->determine_units_weight_lb($max_weight_45_ba_pa, $total_weight);
             } else {
               $parameters = $this->determine_units_weight_lb($max_weight_12_ba_pa, $total_weight);
             }
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             if ($country_zone1 == TRUE) {
               $tnt_f_rate = $this->determine_rate($rates_1_rei_pa_eur, $tnt_f_weight);
             } elseif ($country_zone2 == TRUE) {
               $tnt_f_rate = $this->determine_rate($rates_2_rei_pa_eur, $tnt_f_weight);
             } else {
               $tnt_f_rate = $this->determine_rate($rates_4_rei_pa_eur, $tnt_f_weight);
             }
             $total_costs = $tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING'));
             if ($tnt_f_weight_lb == 0) {
               $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ';
             } else {
               if ($country_zone1 == TRUE) {
                 $tnt_f_rate = $this->determine_rate($rates_1_rei_pa_eur, $tnt_f_weight_lb);
               } elseif ($country_zone2 == TRUE) {
                 $tnt_f_rate = $this->determine_rate($rates_2_rei_pa_eur, $tnt_f_weight_lb);
               } else {
                 $tnt_f_rate = $this->determine_rate($rates_4_rei_pa_eur, $tnt_f_weight_lb);
               }
               $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
               $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ';
             }
             if (($this->getConfigData('MODULE_SH_TNT_SB') == 1) and ($tnt_f_sb == TRUE)) {
               if ($tnt_f_weight_lb == 0) {
                 $total_costs += (float)($tnt_f_units * $this->getConfigData('MODULE_SH_TNT_PRICE_SB'));
               } else {
                 $total_costs += (float)(($tnt_f_units + 1) * $this->getConfigData('MODULE_SH_TNT_PRICE_SB'));
               }
             }
             if ($country_zone1 == TRUE) {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_EUR_Z1_PACKAGE');
             } elseif ($country_zone2 == TRUE) {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_EUR_Z2_PACKAGE');
             } else {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_EUR_Z4_PACKAGE');
             }
             $methods[] = array('id' => 'REIPAEUR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  (=INSURANCESERVICE)  *****************************************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_REI_PA_WO') == 1) and
             ($country_zone5 == TRUE) and
             (((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_45_ba_pa) and
               (($total_weight  + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))
              or ($this->getConfigData('MODULE_SH_TNT_MLT_REI_WO') == 1))) {
             $parameters = $this->determine_units_weight_lb($max_weight_45_ba_pa, $total_weight);
             $tnt_f_units = $parameters['units'];
             $tnt_f_weight = $parameters['weight_box'];
             $tnt_f_weight_lb = $parameters['weight_lb'];
             $tnt_f_rate = $this->determine_rate($rates_5_rei_pa_wo, $tnt_f_weight);
             $total_costs = $tnt_f_units * ($tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING'));
             if ($tnt_f_weight_lb == 0) {
               $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ';
             } else {
               $tnt_f_rate = $this->determine_rate($rates_5_rei_pa_wo, $tnt_f_weight_lb);
               $total_costs += $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
               $title = $tnt_f_units . 'x' . $tnt_f_weight . '+1x' . $tnt_f_weight_lb . ' gr; ';
             }
             if (($this->getConfigData('MODULE_SH_TNT_SB') == 1) and ($tnt_f_sb == TRUE)) {
               if ($tnt_f_weight_lb == 0) {
                 $total_costs += (float)($tnt_f_units * $this->getConfigData('MODULE_SH_TNT_PRICE_SB'));
               } else {
                 $total_costs += (float)(($tnt_f_units + 1) * $this->getConfigData('MODULE_SH_TNT_PRICE_SB'));
               }
             }
             $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_REI_WO_Z5_PACKAGE');
             $methods[] = array('id' => 'REIPAWO',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  (=SPEEDSERVICE)  *********************************************************
         if (($tnt_f_lp == 4) and ($this->getConfigData('MODULE_SH_TNT_GA_PA_EUR') == 1) and
             (($country_zone1 == TRUE) or ($country_zone2 == TRUE)) and
             ((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight_12_ga_pa) and
              (($total_weight  + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')))) {
             $tnt_f_units = 1;
             $tnt_f_weight = (float)$total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT');
             if ($country_zone1 == TRUE) {
               $tnt_f_rate = $this->determine_rate($rates_1_ga_pa_eur, $tnt_f_weight);
             } else {
               $tnt_f_rate = $this->determine_rate($rates_2_ga_pa_eur, $tnt_f_weight);
             }
             $total_costs = $tnt_f_rate + (float)$this->getConfigData('MODULE_SH_TNT_PACKAGE_HANDLING');
             $title = $tnt_f_units . 'x' . $tnt_f_weight . ' gr; ';
             if ($country_zone1 == TRUE) {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_GA_EUR_Z1_PACKAGE');
             } else {
               $title .= __('MODULE_SHIPPING_TNTPOST_F_TEXT_GA_EUR_Z2_PACKAGE');
             }
             $methods[] = array('id' => 'GAPAEUR',
                                'title' => $title,
                                'cost' => $total_costs);
         }
     //**********************  NO TNT  ******************************************************************
         if (sizeof($methods) == 0) {
             return (FALSE); // no methods specified
         }
     }

     // always insuranceservice when above limit for outside home country
     if ((!($this->dest_country == 'NL')) and ($this->getConfigData('MODULE_SH_TNT_INS_SERVICE') == 1)) {
   	   $T = (float)($sub_total);
   	   if ($T >= ((float)$this->getConfigData('MODULE_SH_TNT_INS_AMOUNT_SERVICE'))) {
   	     $methods_save = array();
   	     for ($i = 0; $i < sizeof($methods); $i++) {
           if (($methods[$i]['id'] == 'REILEEUR') or ($methods[$i]['id'] == 'REILEWO') or ($methods[$i]['id'] == 'REIPAEUR') or ($methods[$i]['id'] == 'REIPAWO')) {
             $methods_save[] = $methods[$i];
           }
   	     }
   	     $methods = $methods_save;
   	   }
     }

     // cheapest rate ?
     if ($this->getConfigData('MODULE_SH_TNT_BEST_RATE') == 1) {
       for ($i = 0; $i < sizeof($methods); $i++) {
       	 if ($i == 0) {
       	   $cheapest_rate = $methods[$i]['cost'];
      	   $cheapest_id = $i;
       	   continue;
       	 }
       	 if ($methods[$i]['cost'] < $cheapest_rate) {
       	   $cheapest_rate = $methods[$i]['cost'];
       	   $cheapest_id = $i;
       	 }
       }

       $methods_save = array();
       $methods_save[] = array('id' => $methods[$cheapest_id]['id'],
                               'title' => $methods[$cheapest_id]['title'],
                               'cost' => $methods[$cheapest_id]['cost']);
       $methods = $methods_save;
     }

     $_result = $this->shippingRateResultFactory->create();

     for ($i = 0; $i < sizeof($methods); $i++) {

      $_method = $this->quoteQuoteAddressRateResultMethodFactory->create();

      $_method->setCarrier($this->_code);
      $_method->setCarrierTitle(__('MODULE_SHIPPING_TNTPOST_F_TEXT_NAME'));
      $_method->setMethod($methods[$i]['id']);
      $_method->setMethodTitle($methods[$i]['title']);
      $_method->setCost(0.00);
      $_method->setPrice($methods[$i]['cost']);

      $_result->append($_method);
     }

     return $_result;
    }

    public function getAllowedMethods()
    {
      return array($this->_code=>$this->getConfigData('name'));
    }

    public function classify_country_zone($geo_zone_name = '')
   	{

	  $result = FALSE;
      $arr = array();

      if ($geo_zone_name == "TNT_EUR") {
        $arr = preg_split("/[,]/" , $this->getConfigData('MODULE_SH_TNT_COUNTRIES_EUROPE'));
      }
      if ($geo_zone_name == "TNT_ZONE_EUR1") {
        $arr = preg_split("/[,]/" , $this->getConfigData('MODULE_SH_TNT_COUNTRIES_EUR1'));
      }
      if ($geo_zone_name == "TNT_ZONE_EUR2") {
        $arr = preg_split("/[,]/" , $this->getConfigData('MODULE_SH_TNT_COUNTRIES_EUR2'));
      }
      if ($geo_zone_name == "TNT_ZONE_EUR3") {
        $arr = preg_split("/[,]/" , $this->getConfigData('MODULE_SH_TNT_COUNTRIES_EUR3'));
      }

      if (in_array($this->dest_country, $arr)) {
        $result = TRUE;
      }

      return $result;
    }

    public function determine_max_weight($rates = array())
    {

   	  $size = sizeof($rates);
      if ($size > 1) {
        return (float)$rates[$size - 2];
      } else {
        return 0;
      }
    }

    public function determine_rate($rates = array(), $weight = 0.0)
    {

   	  $rate = 0;
   	  $size = sizeof($rates);
      if ($size > 1) {
        for ($i=0, $n=$size; $i<$n; $i+=2) {
          if ($weight <= (float)$rates[$i]) {
            return $rate = (float)$rates[$i+1];
          }
        }
      } else {
        return 0;
      }
    }

    public function determine_units_weight_lb($max_weight = 0.0, $total_weight)
    {

      $parameters = array();
      $weight_box = 0.0;
   	  if ((($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= $max_weight) and
          (($total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')) <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT'))) {
        $parameters['units'] = 1;
        $parameters['weight_box'] = $total_weight + (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT');
        $parameters['weight_lb'] = 0;
      } else {
        if ($max_weight <= (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT')) {
       	  $weight_box = $max_weight;
        } else {
          $weight_box = (float)$this->getConfigData('MODULE_SH_TNT_MAX_WEIGHT');
        }
     	$parameters['units'] = (int)floor($total_weight / ($weight_box - (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')));
     	$parameters['weight_box'] = $weight_box;
     	$parameters['weight_lb'] = $total_weight -
     	                            ($parameters['units'] * ($weight_box - (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT')));
     	if ($parameters['weight_lb'] > 0) {
     	  $parameters['weight_lb'] += (float)$this->getConfigData('MODULE_SH_TNT_BOX_WEIGHT');
     	}
      }
      return $parameters;
    }

    public function get_shipping_tax_rate()
    {
      $calc = $this->taxCalculation;
      $config = $this->taxConfig;
      $shippingAddress = $this->checkoutSession->getQuote()->getShippingAddress();
      $store = $shippingAddress->getQuote()->getStore();
      $addressTaxRequest = $calc->getRateRequest(
            $shippingAddress,
            $shippingAddress->getQuote()->getBillingAddress(),
            $shippingAddress->getQuote()->getCustomerTaxClassId(),
            $store
      );
      $shippingTaxClass = $config->getShippingTaxClass($store);
      $addressTaxRequest->setProductClassId($shippingTaxClass);
      $rate = $calc->getRate($addressTaxRequest);

      return ($rate/100);
    }

}
 