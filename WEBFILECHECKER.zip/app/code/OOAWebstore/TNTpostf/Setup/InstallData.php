<?php
namespace OOAWebstore\TNTpostf\Setup;

/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */

class InstallData implements \Magento\Framework\Setup\InstallDataInterface
{
	protected $eavSetupFactory;

    public function __construct(\Magento\Eav\Setup\EavSetupFactory $eavSetupFactory)
    {
        $this->eavSetupFactory = $eavSetupFactory;
    }
    
    public function install(\Magento\Framework\Setup\ModuleDataSetupInterface $setup, \Magento\Framework\Setup\ModuleContextInterface $context)
    {

        $eavSetup = $this->eavSetupFactory->create(['setup' => $setup]);
 
        $eavSetup->addAttribute(
	            \Magento\Catalog\Model\Product::ENTITY,
	            'tntpostf_height',
	            [
	            		'group'             => 'General',
	            		'label'             => 'PostNL height',
	            		'type'              => 'varchar',
	            		'input'             => 'text',
	            		'default'           => '0.0000',
	            		'class'             => 'validate-number',
	            		'backend'           => '',
	            		'frontend'          => '',
	            		'source'            => '',
	            		'global'            => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
	            		'visible'           => true,
	            		'required'          => true,
	            		'user_defined'      => true,
	            		'searchable'        => false,
	            		'filterable'        => false,
	            		'comparable'        => false,
	            		'visible_on_front'  => false,
	            		'visible_in_advanced_search' => false,
	            		'unique'            => false
	           ]
        );
        
        $eavSetup->addAttribute(
        		\Magento\Catalog\Model\Product::ENTITY,
        		'tntpostf_maxplet',
        		[
						'group'             => 'General',
						'label'             => 'PostNL max/letter',
						'type'              => 'varchar',
						'input'             => 'text',
						'default'           => '1',
						'class'             => 'validate-digits',
						'backend'           => '',
						'frontend'          => '',
						'source'            => '',
						'global'            => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
						'visible'           => true,
						'required'          => true,
						'user_defined'      => true,
						'searchable'        => false,
						'filterable'        => false,
						'comparable'        => false,
						'visible_on_front'  => false,
						'visible_in_advanced_search' => false,
						'unique'            => false
        		]
        );
        
        $eavSetup->addAttribute(
        		\Magento\Catalog\Model\Product::ENTITY,
        		'tntpostf_shipping',
        		[
						'group'             => 'General',
						'label'             => 'PostNL shipping',
						'type'              => 'int',
						'input'             => 'boolean',
						'default'           => '1',
						'class'             => '',
						'backend'           => '',
						'frontend'          => '',
						'source'            => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
						'global'            => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
						'visible'           => true,
						'required'          => false,
						'user_defined'      => true,
						'searchable'        => false,
						'filterable'        => false,
						'comparable'        => false,
						'visible_on_front'  => false,
						'visible_in_advanced_search' => false,
						'unique'            => false
        		]
        );
        
        $eavSetup->addAttribute(
        		\Magento\Catalog\Model\Product::ENTITY,
        		'tntpostf_package',
        		[
						'group'             => 'General',
						'label'             => 'PostNL package',
						'type'              => 'int',
						'input'             => 'boolean',
						'default'           => '1',
						'class'             => '',
						'backend'           => '',
						'frontend'          => '',
						'source'            => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
						'global'            => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
						'visible'           => true,
						'required'          => false,
						'user_defined'      => true,
						'searchable'        => false,
						'filterable'        => false,
						'comparable'        => false,
						'visible_on_front'  => false,
						'visible_in_advanced_search' => false,
						'unique'            => false
        		]
        );
        
        $eavSetup->addAttribute(
        		\Magento\Catalog\Model\Product::ENTITY,
        		'tntpostf_sealbag',
        		[
						'group'             => 'General',
						'label'             => 'PostNL sealbag',
						'type'              => 'int',
						'input'             => 'boolean',
						'default'           => '0',
						'class'             => '',
						'backend'           => '',
						'frontend'          => '',
						'source'            => 'Magento\Eav\Model\Entity\Attribute\Source\Boolean',
						'global'            => \Magento\Catalog\Model\ResourceModel\Eav\Attribute::SCOPE_GLOBAL,
						'visible'           => true,
						'required'          => false,
						'user_defined'      => true,
						'searchable'        => false,
						'filterable'        => false,
						'comparable'        => false,
						'visible_on_front'  => false,
						'visible_in_advanced_search' => false,
						'unique'            => false
        		]
        );
        
    }
}
