<?php
namespace OOAWebstore\Orders\Block\Adminhtml\Sales\Order;

/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */
class Grid extends \Magento\Backend\Block\Widget\Grid\Extended
{

    protected $salesResourceModelOrderCollectionFactory;

    protected $scopeConfig;

    protected $salesOrderConfig;
    
    protected $resource;
    
    public function __construct(
    	\Magento\Backend\Block\Template\Context $context,
    	\Magento\Backend\Helper\Data $ordersHelper,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $salesResourceModelOrderCollectionFactory,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Sales\Model\Order\Config $salesOrderConfig,
    	\Magento\Framework\App\ResourceConnection $resource,    		
    	array $data = []
    )
    {
        $this->salesResourceModelOrderCollectionFactory = $salesResourceModelOrderCollectionFactory;
        $this->scopeConfig = $scopeConfig;
        $this->salesOrderConfig = $salesOrderConfig;
        $this->resource = $resource;
        parent::__construct($context, $ordersHelper, $data);
    }

    protected function _construct()
    {
    	parent::_construct();
        $this->setId('ooawebstore_orders_sales_order_grid');
        $this->setDefaultSort('increment_id');
        $this->setDefaultDir('DESC');
        $this->setSaveParametersInSession(true);
        $this->setUseAjax(true);
    }
    
    protected function _prepareCollection()
    {
        $collection = $this->salesResourceModelOrderCollectionFactory->create();
        $tablePrefix = (string) $this->resource->getTableName("sales_order_address");
        $tablePrefix = ""; // later
        $collection->getSelect()
            ->join(array('a' => $tablePrefix . 'sales_order_address'), 'main_table.entity_id = a.parent_id AND a.address_type != \'billing\'', array(
                'city'       => 'city',
                'country_id' => 'country_id'
            ));
        $collection->getSelect()
            ->join(array('c' => $tablePrefix . 'customer_group'), 'main_table.customer_group_id = c.customer_group_id', array(
                'customer_group_code' => 'customer_group_code'
            ));
        $collection->addExpressionFieldToSelect(
                'fullname',
                'CONCAT({{customer_firstname}}, \' \', {{customer_lastname}})',
                array('customer_firstname' => 'main_table.customer_firstname', 'customer_lastname' => 'main_table.customer_lastname'));
        $collection->addExpressionFieldToSelect(
                'products',
                '(SELECT GROUP_CONCAT(\' \', x.name)
                    FROM ' . $tablePrefix . 'sales_order_item x
                    WHERE {{entity_id}} = x.order_id
                        AND x.product_type != \'configurable\')',
                array('entity_id' => 'main_table.entity_id')
            )
        ;
        $collection->addFieldToFilter('status', array("in" => array($this->scopeConfig->getValue('carriers/tntpostf/MODULE_SH_TNT_STATUS_PARCELWARE', \Magento\Store\Model\ScopeInterface::SCOPE_STORE))));
    	$this->setCollection($collection);
        parent::_prepareCollection();
        return $this;
    }

    protected function _prepareColumns()
    {
    	$tablePrefix = (string) $this->resource->getTableName("sales_order_item");
    	$tablePrefix = ""; // later
        $currency = (string) $this->scopeConfig->getValue(\Magento\Directory\Model\Currency::XML_PATH_CURRENCY_BASE, \Magento\Store\Model\ScopeInterface::SCOPE_STORE);
        $this->addColumn('increment_id', array(
            'header' => __('Order #'),
            'index'  => 'increment_id'
        ));
        $this->addColumn('purchased_on', array(
            'header' => __('Purchased On'),
            'type'   => 'datetime',
            'index'  => 'created_at'
        ));
        $this->addColumn('products', array(
            'header'       => __('Products Purchased'),
            'index'        => 'products',
            'filter_index' => '(SELECT GROUP_CONCAT(\' \', x.name) FROM ' . $tablePrefix . 'sales_order_item x WHERE main_table.entity_id = x.order_id AND x.product_type != \'configurable\')'
        ));
        $this->addColumn('fullname', array(
            'header'       => __('Name'),
            'index'        => 'fullname',
            'filter_index' => 'CONCAT(customer_firstname, \' \', customer_lastname)'
        ));
        $this->addColumn('city', array(
            'header' => __('City'),
            'index'  => 'city'
        ));
        $this->addColumn('country', array(
            'header'   => __('Country'),
            'index'    => 'country_id'
            //'renderer' => 'adminhtml\widget\grid\column\renderer\country' later
        ));
        $this->addColumn('customer_group', array(
            'header' => __('Customer Group'),
            'index'  => 'customer_group_code'
        ));
        $this->addColumn('grand_total', array(
            'header'        => __('Grand Total'),
            'index'         => 'grand_total',
            'type'          => 'currency',
            'currency_code' => $currency
        ));
        $this->addColumn('shipping_method', array(
            'header' => __('Shipping Method'),
            'index'  => 'shipping_description'
        ));
        $this->addColumn('order_status', array(
            'header'  => __('Status'),
            'index'   => 'status',
            'type'    => 'options',
            'options' => $this->salesOrderConfig->getStatuses(),
        ));
        $this->addExportType('*/*/exportOOATNTpostfCsv', __('CSV'));
        return parent::_prepareColumns();
    }

    public function getGridUrl()
    {
        return $this->getUrl('*/*/grid', array('_current'=>true));
    }
    
}
