<?php
namespace OOAWebstore\Orders\Controller\Adminhtml\Order;

/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */
class Grid extends \Magento\Backend\App\Action
{
	protected $resultLayoutFactory;
	
    public function __construct(
            \Magento\Backend\App\Action\Context $context,
            \Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
    		array $data = []
    ) {
       parent::__construct($context, $data);
       $this->resultLayoutFactory = $resultLayoutFactory;
    }
    public function execute()  
    {
    }
	    
}
