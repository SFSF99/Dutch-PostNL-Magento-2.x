<?php
namespace OOAWebstore\Orders\Controller\Adminhtml\Order;

/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */
class Index extends \Magento\Backend\App\Action
{
	protected $resultPageFactory;
	
    public function __construct(
       \Magento\Backend\App\Action\Context $context,
       \Magento\Framework\View\Result\PageFactory $resultPageFactory,
       array $data = []
    ) {
       parent::__construct($context, $data);
       $this->resultPageFactory = $resultPageFactory;
    }
    public function execute()
    {
    	$resultPage = $this->resultPageFactory->create();
    	$resultPage->setActiveMenu('OOAWebstore_Orders::Order');
    	$resultPage->addBreadcrumb(__('Sales'), __('Sales'));
    	$resultPage->addBreadcrumb(__('Orders - Parcelware'), __('Orders - Parcelware'));
    	$resultPage->getConfig()->getTitle()->prepend(__('Orders - Parcelware'));
    	$resultPage->addContent(
    			$resultPage->getLayout()->createBlock('OOAWebstore\Orders\Block\Adminhtml\Sales\Order\Grid')
    	);
    	return $resultPage;
    }
        
}
