<?php
namespace OOAWebstore\Orders\Controller\Adminhtml\Order;

/*
 *
 * @category   OOA
 * @package    OOA_Tntpostf
 * @copyright  Open Software (2016)
 *
 */
class exportOOATNTpostfCsv extends \Magento\Backend\App\Action
{
	    protected $resultLayoutFactory;
	    
	    protected $salesResourceModelOrderCollectionFactory;
	    
	    protected $scopeConfig;
	    
	    protected $countryFactory;
	    
	    protected $resource;
	
        public function __construct(
        	\Magento\Backend\App\Action\Context $context,
        	\Magento\Framework\View\Result\LayoutFactory $resultLayoutFactory,
        	\Magento\Sales\Model\ResourceModel\Order\CollectionFactory $salesResourceModelOrderCollectionFactory,
        	\Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        	\Magento\Directory\Model\CountryFactory $countryFactory,
        	\Magento\Framework\App\ResourceConnection $resource,
        	array $data = []
        ) {
            parent::__construct($context, $data);
            $this->resultLayoutFactory = $resultLayoutFactory;
            $this->salesResourceModelOrderCollectionFactory = $salesResourceModelOrderCollectionFactory;
            $this->scopeConfig = $scopeConfig;
            $this->countryFactory = $countryFactory;
            $this->resource = $resource;
        }
        public function execute()
        {
	    	$tablePrefix = (string) $this->resource->getTableName("sales_order_item");
	    	$tablePrefix = ""; // later
        	$collection = $this->salesResourceModelOrderCollectionFactory->create();
        	$collection->getSelect()
        	->join(array('a' => $tablePrefix . 'sales_order_address'), 'main_table.entity_id = a.parent_id AND a.address_type != \'billing\'', array(
        			'city'       => 'city',
        			'country_id' => 'country_id'
        	));
        	$collection->getSelect()
        	->join(array('c' => $tablePrefix . 'customer_group'), 'main_table.customer_group_id = c.customer_group_id', array(
        			'customer_group_code' => 'customer_group_code'
        	));
        	$collection->addExpressionFieldToSelect(
        			'fullname',
        			'CONCAT({{customer_firstname}}, \' \', {{customer_lastname}})',
        			array('customer_firstname' => 'main_table.customer_firstname', 'customer_lastname' => 'main_table.customer_lastname'));
        	$collection->addExpressionFieldToSelect(
        			'products',
        			'(SELECT GROUP_CONCAT(\' \', x.name)
                    FROM ' . $tablePrefix . 'sales_order_item x
                    WHERE {{entity_id}} = x.order_id
                        AND x.product_type != \'configurable\')',
        			array('entity_id' => 'main_table.entity_id')
        	)
        	;
        	$collection->addFieldToFilter('status', array("in" => array($this->scopeConfig->getValue('carriers/tntpostf/MODULE_SH_TNT_STATUS_PARCELWARE', \Magento\Store\Model\ScopeInterface::SCOPE_STORE))));
        
        	$collection->load();
        
        	$cy = $this->countryFactory->create();

        	$outputFile = "postnl_parcelware_". date('Ymd_His').".csv";
        	$handle = fopen($outputFile, 'w');
        	
        	$contents = ["ReferenceNr",
        	             "Title",
			        	 "Name1",
			        	 "Name2",
			        	 "Name3",
			        	 "Street",
			        	 "HomeNr",
			        	 "HomeNrExt",
			        	 "ZIP",
			        	 "City",
			        	 "AddressDetails",
			        	 "Country",
			        	 "Telephone",
			        	 "MobileTelephone",
			        	 "FAX",
			        	 "Email",
			        	 "TAXnr",
			        	 "Remark"];
        	
        	fputcsv($handle, $contents);
        	
        	foreach ($collection as $order) {
        		$row = $order->getShippingAddress()->getData();
        
        		if ($row['country_id'] == 'NL') {
        			$address_parts = $this->split_address($row['street']);
        			$row['street'] = $address_parts["streetname"];
        			$row['HomeNr'] = $address_parts["streetnr"] . $address_parts["streetnrext"];
        		}
        		
        		
        		$contents = [
		    	         $order->getIncrementId(),
		    	         "",
		    	         $row['firstname']." ".$row['middlename']." ".$row['lastname'],
		    	         "",
		    	         "",
		    	         $row['street'],
		    	         $row['HomeNr'],
		    	         "",
		    	         $row['postcode'],
		    	         $row['city'],
		    	         "",
		    	         $cy->load($row['country_id'])->getName(),
		    	         $row['telephone'],
		    	         "",
		    	         $row['fax'],
		    	         $row['email'],
		    	         "",
		    	         ""];
		    	
        		fputcsv($handle, $contents);        		
        	};
        	
        	$this->downloadCsv($outputFile);        	
        }
        public function split_address($full_address) {
        	list($address["streetname"]) = preg_split("/ [0-9]+/", $full_address);
        	list($leeg,$rest) = @preg_split("/" . $address["streetname"] . "/", $full_address);
        	preg_match("/[0-9]+/", $rest, $regs);
        	list($address["streetnr"]) = $regs;
        	list($leeg,$address["streetnrext"]) = @preg_split("/" . $address["streetnr"] . "/", $rest);
        	return $address;
        }
        public function downloadCsv($file)
        {
        	if (file_exists($file)) {
        		//set appropriate headers
        		header('Content-Description: File Transfer');
        		header('Content-Type: application/csv');
        		header('Content-Disposition: attachment; filename='.basename($file));
        		header('Expires: 0');
        		header('Cache-Control: must-revalidate');
        		header('Pragma: public');
        		header('Content-Length: ' . filesize($file));
        		ob_clean();flush();
        		readfile($file);
        	}
        }	    
}
